// Copyright (c) Meta Platforms, Inc. and affiliates.

/**
 * @file CommandDoc for `astryx docs`. The terminal binding of the `docs()`
 * function (referenced via `fn`); its args/flags map to that function's params
 * so a converter can build Commander config + --help from one source of truth.
 * @position packages/cli/clients/cli/commands — command documentation
 */

/** @type {import('@astryxdesign/cli/authoring').CommandDoc} */
export const doc = {
  type: 'command',
  name: 'docs',
  displayName: 'astryx docs',
  namespace: 'cli/commands',
  summary: 'Print reference docs',
  description:
    'Reads the reference docs one level at a time: with no topic it lists every topic; a ' +
    'topic lists its sections, each with the key to read it by (a topic with one section ' +
    'prints whole); a topic plus a section prints that section; `--full` prints the whole ' +
    'topic, as does `--dense`. With `--json`, a topic returns its whole doc, as docs() ' +
    'does, and `--index` its section index. A route ' +
    'opens a node of the docs tree: `cli` lists its guides and reference, ' +
    '`cli/api/functions` lists every API function, and `cli/api/functions/search` prints ' +
    'one.',
  fn: 'docs',
  args: [
    {name: 'topic', param: 'topic', required: false},
    {name: 'section', param: 'section', required: false},
  ],
  options: [
    {
      flag: '--index',
      param: 'options.index',
      description: "List the topic's sections and their keys, even for a topic with one section",
    },
    {
      flag: '--full',
      description:
        'Print the whole topic instead of its sections (text; `--json` returns the whole topic unless --index). Cannot be set with --index',
    },
  ],
  examples: [
    {label: 'List topics', cli: 'astryx docs'},
    {label: "A topic's sections", cli: 'astryx docs theme'},
    {label: 'A whole topic as JSON', cli: 'astryx docs spacing --json'},
    {label: 'One section', cli: 'astryx docs theme quick-start'},
    {label: 'The CLI docs tree', cli: 'astryx docs cli'},
    {label: 'One API function', cli: 'astryx docs cli/api/functions/search'},
    {label: 'A whole guide', cli: 'astryx docs cli/integrations/quick-start --full'},
  ],
  exitCodes: [
    {code: 0, when: 'success'},
    {
      code: 1,
      when: 'unknown topic or route, or a section that matches no section or more than one',
    },
  ],
  related: ['search', 'component', 'hook', 'template'],
};
