// Copyright (c) Meta Platforms, Inc. and affiliates.

/**
 * @file FunctionDoc for `component()` / `astryx component`. Colocated with the
 * API function it documents; the shape source of truth stays in
 * `component.type.mjs`.
 * @position packages/cli/api/component — function documentation
 */

/** @type {import('@astryxdesign/cli/authoring').FunctionDoc} */
export const doc = {
  type: 'function',
  kind: 'api',
  name: 'component',
  namespace: 'cli/api',
  displayName: 'component()',
  summary:
    'Resolve components by name, list the catalog, or read vanilla HTML/web-component markup, with optional focused slices (props, source, showcase, blocks).',
  description:
    'Routes on its arguments: one string resolves that component across core and ' +
    'integration packages; an array returns one ordered result row per selector at ' +
    'every array length; and no name returns the catalog grouped by category. ' +
    'Boolean flags narrow each resolved component to just its props, source, ' +
    'showcase, or example blocks. The framework option selects React docs (default), ' +
    'vanilla HTML markup, or vanilla web-component markup. The html option is a ' +
    'deprecated alias for framework=html. When Core is not installed, details, props, ' +
    'and lists come from the version-matched Core snapshot shipped with the CLI; the ' +
    'response meta identifies that package version. Configured integration components ' +
    'remain available only when Core is installed.',
  importPath: '@astryxdesign/cli/api',
  signature:
    'component(name?: string | string[], options?: ComponentOptions): Promise<ComponentListResponse | ComponentBatchResponse | ComponentDetailResponse | ComponentDetailPropsResponse | ComponentDetailSourceResponse | ComponentDetailShowcaseResponse | ComponentDetailBlocksResponse | ComponentHtmlListResponse | ComponentHtmlResponse | ComponentWebComponentsListResponse | ComponentWebComponentsResponse>',
  keywords: [
    'component',
    'components',
    'props',
    'source',
    'showcase',
    'blocks',
    'catalog',
  ],
  params: [
    {
      name: 'name',
      type: 'string | string[]',
      description:
        "Pass one selector string for the existing single-result response, or an array of at most 100 selectors for an ordered component.batch response. The limit counts duplicates in every projection mode. An array always requests a batch, including [] and ['Button']. Use 'Button', 'widgets/Button', '@acme/widgets/Button', or '@acme/widgets@1.2.3/Button'. A version applies to the package and must match the installed version. Omit the argument to list the catalog.",
    },
    {
      name: 'options.cwd',
      type: 'string',
      description:
        'Directory to resolve @astryxdesign/core from. Without a local installation, list, detail, and props reads use the version-matched Core snapshot bundled with the CLI.',
      default: 'process.cwd()',
    },
    {
      name: 'options.list',
      type: 'boolean',
      description: 'Return the grouped catalog instead of a single component.',
    },
    {
      name: 'options.category',
      type: 'string',
      description:
        "List only the components in this group: a key of the unfiltered list (each component's group field), such as 'Layout' or 'Button'. It is not the category field of a component detail.",
    },
    {
      name: 'options.package',
      type: 'string',
      description:
        "Scope lookup to a specific external package (e.g. '@acme/widgets').",
    },
    {
      name: 'options.props',
      type: 'boolean',
      description: "Return only the component's props table.",
    },
    {
      name: 'options.source',
      type: 'boolean',
      description: "Return the component's source file.",
    },
    {
      name: 'options.showcase',
      type: 'boolean',
      description: "Return the component's showcase example.",
    },
    {
      name: 'options.blocks',
      type: 'boolean',
      description:
        "Return the component's example blocks (showcase, examples, related).",
    },
    {
      name: 'options.framework',
      type: "'react' | 'html' | 'web-components'",
      description:
        'Choose React component docs (default), vanilla HTML markup, or vanilla web-component markup.',
      default: "'react'",
    },
    {
      name: 'options.html',
      type: 'boolean',
      description: 'Deprecated alias for options.framework=html.',
    },
    {
      name: 'options.detail',
      type: "'full' | 'compact' | 'brief'",
      description: 'Detail level for list views.',
      default:
        "'full' for a named component; 'brief' for lists (returned as data.detail: 'names')",
    },
    {
      name: 'options.lang',
      type: 'string',
      description:
        "Language code for localized doc content: 'en', 'zh', or 'dense'.",
    },
    {
      name: 'options.zh',
      type: 'boolean',
      description: 'Shorthand for Chinese (zh) doc content.',
    },
    {
      name: 'options.dense',
      type: 'boolean',
      description: 'Return the token-efficient dense doc variant.',
    },
  ],
  returns: [
    {
      type: 'component.list',
      description:
        "The catalog grouped by component group. data.detail is the level ('names' | 'compact' | 'full') and data.components is the grouped map: names entries with name, package, and an optional canonical import for integration and legacy package components; brief entries; or full ComponentDoc entries.",
    },
    {
      type: 'component.batch',
      description:
        'An explicit selector array returns one ordered receipt at every array length: count and one results row per selector, including duplicates. ComponentBatchResponse specializes the shared BatchResponse and BatchRow types. Each row carries selector and status (found, not_found, ambiguous, or error); found rows carry the single-selector result, ambiguous rows carry installed candidates ({package, component, kind, installed}), and failed rows carry code, error, and optional suggestions.',
    },
    {
      type: 'component.detail',
      description:
        "One component's authored ComponentDoc plus ownership metadata (owner package, import specifier, whether source is available). When bundled docs are used, meta.componentDocs names their package, version, and bundled source. When the name is a sub-component documented in a parent's doc, the payload is scoped to it and parentDoc names that parent.",
    },
    {
      type: 'component.detail.props',
      description: "Just the component's props table (ComponentPropDoc[]).",
    },
    {
      type: 'component.detail.source',
      description: "The component's source file, as {component, source}.",
    },
    {
      type: 'component.detail.showcase',
      description:
        "The component's showcase example, as {component, aspectRatio, source}.",
    },
    {
      type: 'component.detail.blocks',
      description:
        "The component's example blocks, as {component, showcase, examples, related} of BlockEntry.",
    },
    {
      type: 'component.html.list',
      description: 'The sorted vanilla component markup files as {name, file}.',
    },
    {
      type: 'component.html',
      description:
        'One vanilla markup file as {component, file, source}; source includes its docs and variant comments verbatim.',
    },
    {
      type: 'component.web-components.list',
      description:
        'The sorted vanilla web-component markup files as {name, file}.',
    },
    {
      type: 'component.web-components',
      description:
        'One vanilla web-component markup file as {component, file, source}.',
    },
  ],
  throws: [
    {
      code: 'ERR_INVALID_ARGUMENT',
      when: 'the framework is unknown; html and framework are combined; a selector array has more than 100 entries; a package-shaped selector has no component item; its package conflicts with options.package; or a vanilla framework is missing its required name/list shape or combined with another projection',
    },
    {
      code: 'ERR_INVALID_DETAIL',
      when: "options.detail is not 'full', 'compact', or 'brief'",
    },
    {
      code: 'ERR_INVALID_LANG',
      when: "options.lang is set to anything other than 'en', 'zh', or 'dense'",
    },
    {
      code: 'ERR_CORE_NOT_FOUND',
      when: '@astryxdesign/core cannot be resolved from cwd and a source, showcase, or block view requires installed package files',
    },
    {
      code: 'ERR_UNKNOWN_CATEGORY',
      when: 'options.category is not a string or matches no component group',
    },
    {
      code: 'ERR_UNKNOWN_COMPONENT',
      when: 'name is not a string, resolves to no known component, is provided by multiple packages (pass options.package), or is absent from the requested options.package',
    },
    {
      code: 'ERR_UNKNOWN_PACKAGE',
      when: 'options.package names a legacy external package that cannot be found, or a package-qualified selector requests a version that is not installed',
    },
    {
      code: 'ERR_NO_DOC',
      when: 'the resolved component has no .doc.mjs typed doc file',
    },
    {
      code: 'ERR_INVALID_DOC',
      when: "the resolved component's .doc.mjs fails to load or validate",
    },
    {
      code: 'ERR_NO_SOURCE',
      when: 'options.source is set but the component has no source file',
    },
    {
      code: 'ERR_NO_SHOWCASE',
      when: 'options.showcase is set but the component has no showcase',
    },
  ],
  examples: [
    {
      label: 'Look up a component',
      code: "const r = await component('Button');",
    },
    {
      label: 'Look up several components',
      code: "await component(['Button', 'Badge']);",
    },
    {label: 'Props only', code: "await component('Button', {props: true});"},
    {
      label: 'Vanilla HTML',
      code: "await component('Button', {framework: 'html'});",
    },
    {
      label: 'Vanilla web component',
      code: "await component('Button', {framework: 'web-components'});",
    },
    {
      label: 'Browse one group',
      code: "await component(undefined, {category: 'Layout', detail: 'compact'});",
    },
  ],
  command: 'component',
  related: ['search', 'hook', 'docs', 'template', 'swizzle'],
};
