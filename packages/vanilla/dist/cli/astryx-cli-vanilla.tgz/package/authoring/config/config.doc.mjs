// Copyright (c) Meta Platforms, Inc. and affiliates.

/**
 * @file SchemaDoc for the `astryx.config.*` file (AstryxConfig). Colocated with
 * the schema (`type.ts` + `parse.mjs`) it documents.
 * @position packages/cli/authoring/config — schema documentation
 */

/** @type {import('@astryxdesign/cli/authoring').SchemaDoc} */
export const doc = {
  type: 'schema',
  name: 'config',
  displayName: 'astryx.config',
  namespace: 'authoring',
  description:
    'The optional astryx.config.* file at your project root. Declares which ' +
    'integrations to load, where to route issue links, post-codemod hooks, local ' +
    'debug-log and gap-report handlers, and experimental layout components. All ' +
    'optional; {} is valid.',
  appliesTo: 'astryx.config.{ts,mjs,js}',
  fields: [
    {
      name: 'integrations',
      type: 'string[]',
      description:
        'Package names of Astryx integrations to load alongside core.',
      example: "['@acme/astryx-widgets']",
    },
    {
      name: 'issuesUrl',
      type: 'string',
      description: 'URL that "report an issue" affordances link to.',
    },
    {
      name: 'hooks',
      type: '{ postCodemod?: PostCodemodHook[] }',
      description: 'Lifecycle hooks.',
      fields: [
        {
          name: 'hooks.postCodemod',
          type: 'PostCodemodHook[]',
          description:
            'Commands run after an upgrade applies codemods (e.g. re-run your formatter). Each hook returns a command to execute, or null to skip.',
        },
      ],
    },
    {
      name: 'debug',
      type: '(event: DebugEvent) => void',
      description:
        'Record every command run. The handler is synchronous; promises are not awaited and output goes to stderr. Declare `debug` directly in this file so early commands can discover it. An integration can supply one too, as a `debug` named export from its manifest. Every handler runs: yours first, then each integration\'s in load order (the `integrations` list, then autolinked ones). A handler that throws is skipped; the others still run and the command\'s result does not change. Set `{"astryx": {"inheritDebug": false}}` in package.json to take only your own.',
      example:
        "event => appendFileSync('runs.ndjson', JSON.stringify(event) + '\\n')",
    },
    {
      name: 'gapReport',
      type: 'GapReportHandler',
      description:
        'Handle explicit gap reports in addition to every loaded integration handler. The project handler runs first. Public handlers require caller consent; internal handlers always run.',
      example:
        "{ audience: 'internal', async handle(report, {signal}) { return sendGap(report, {signal}); } }",
    },
    {
      name: 'discover',
      type: 'DiscoverSource',
      description:
        'Tell `astryx discover` which integrations this project could add: an async function that returns a catalog. An integration can provide one too, as a `discover` named export from its manifest. Discover calls every source, yours first, and one that fails never hides the others. Discover only reads; your package manager installs.',
      example:
        "async ({signal, package: name, version}) => fetchCatalog({signal, name, version})",
    },
    {
      name: 'experimental',
      type: '{ xle?: { components?: Record<string, XleComponent> } }',
      description: 'Unstable features; may change without a breaking bump.',
      fields: [
        {
          name: 'experimental.xle.components',
          type: 'Record<string, XleComponent>',
          description:
            'Custom components the layout expander (XLE) may emit, keyed by tag.',
        },
      ],
    },
  ],
  examples: [
    {
      label: 'Minimal',
      code: "export default {\n  integrations: ['@acme/astryx-widgets'],\n};",
    },
    {
      label: 'Send every command run somewhere of your own',
      code:
        'export default {\n' +
        '  debug: event => appendFileSync("runs.ndjson", JSON.stringify(event) + "\\n"),\n' +
        '};',
    },
  ],
  notes: [
    {
      type: 'prose',
      text: 'The config is validated at load with a strict schema: unknown keys are errors, so a typo fails fast rather than being silently ignored.',
    },
  ],
};
